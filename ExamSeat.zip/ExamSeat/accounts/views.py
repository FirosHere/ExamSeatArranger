from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.conf import settings
from types import SimpleNamespace
from .models import Room
import random

import csv
import os
from collections import deque
from .forms import UploadCSVForm, StudentForm

from .models import Student, Room



# ----------------- AUTH -----------------
def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


def home_view(request):
    return render(request, 'home.html')


# ----------------- STUDENTS -----------------
# accounts/views.py

import csv
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UploadCSVForm
from .models import Student

def upload_students(request):
    if request.method == 'POST' and 'upload_csv' in request.POST:
        form = UploadCSVForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['file']
            decoded_file = csv_file.read().decode('utf-8').splitlines()

            # Detect delimiter
            sample_line = decoded_file[0]
            delimiter = '\t' if '\t' in sample_line else ','

            reader = csv.DictReader(decoded_file, delimiter=delimiter)

            # Normalize headers
            raw_headers = [h.strip().lower().replace(" ", "_") for h in reader.fieldnames]

            # Required fields (allow flexible naming)
            required_fields = ['roll_number', 'name','department', 'student_class', 'academic_year']
               # Check required fields
            if 'roll_number' not in raw_headers:
                messages.error(request, "❌ The CSV file must contain a 'roll_number' column.")
                return redirect('upload_students')

            if not any(h in raw_headers for h in ['name', 'student_name']):
                messages.error(request, "❌ The CSV file must contain a 'name' or 'student_name' column.")
                return redirect('upload_students')

        

            # Helper to safely extract values from row
            def get_value(row, *fields):
                normalized_row = {k.strip().lower().replace(" ", "_"): v for k, v in row.items()}
                for field in fields:
                    if field in normalized_row and normalized_row[field]:
                        return normalized_row[field].strip()
                return ""

            created_count = 0
            for row in reader:
                roll = get_value(row, 'roll_number')
                name = get_value(row, 'name', 'student_name')   # ✅ flexible matching

                if roll and name:
                    Student.objects.update_or_create(
                        roll_number=roll,
                        defaults={
                            'name': name,
                            'department': get_value(row, 'department'),
                            'student_class': get_value(row, 'student_class'),
                            'academic_year': get_value(row, 'academic_year'),
                        }
                    )
                    created_count += 1

            if created_count > 0:
                messages.success(request, f"✅ Successfully uploaded {created_count} students.")
            else:
                messages.warning(request, "⚠️ No valid student records were uploaded.")

            return redirect('upload_students')
    else:
        form = UploadCSVForm()

    return render(request, 'upload_students.html', {'form': form})




# Manual Add Student
def add_student_manual(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Student added successfully!")
            return redirect('upload_students')
        else:
            messages.error(request, "Failed to add student. Please check the form.")
    else:
        form = StudentForm()
    return render(request, 'upload_students.html', {'form': form})


# Reset Students DB
def reset_students_db(request):
    if request.method == 'POST':
        Student.objects.all().delete()
        messages.success(request, "All student records deleted successfully!")
        return redirect('upload_students')
# ----------------- ROOMS -----------------
def add_room(request):
    if request.method == "POST":
        room_no = request.POST.get('room_no')
        try:
            benches = int(request.POST.get('benches'))
            rows = int(request.POST.get('rows'))
            columns = int(request.POST.get('columns'))
        except ValueError:
            messages.error(request, "Invalid numbers.")
            return redirect('add_room')

        if Room.objects.filter(room_no=room_no).exists():
            messages.error(request, "Room number exists.")
            return redirect('add_room')

        Room.objects.create(room_no=room_no, benches=benches, rows=rows, columns=columns)
        messages.success(request, "Room added successfully.")
        return redirect('add_room')

    rooms = Room.objects.all()
    return render(request, 'add_room.html', {'rooms': rooms})


def delete_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    room.delete()
    messages.success(request, f"Room {room.room_no} deleted.")
    return redirect('add_room')


# ----------------- SEAT ALLOCATION -----------------
def generate_seats(students):
    """
    Allocate students to benches in rooms, ensuring no duplicates.
    Returns a list of dictionaries per room.
    """
    # Shuffle students for fairness
    students = list(students)
    random.shuffle(students)

    # Group by department
    dept_groups = {}
    for student in students:
        dept_groups.setdefault(student.department, []).append(student)

    dept_queues = {dept: deque(studs) for dept, studs in dept_groups.items()}
    dept_cycle = deque(dept_queues.keys())

    allocation = []

    for room in Room.objects.all():
        benches_list = []
        bench_no = 1
        room_full = False

        for r in range(room.rows):
            row_data = []
            for c in range(room.columns):
                if bench_no <= room.benches:
                    seat1 = None
                    seat2 = None

                    # Allocate first seat
                    while dept_cycle and not seat1:
                        dept = dept_cycle[0]
                        if dept_queues[dept]:
                            seat1 = dept_queues[dept].popleft()
                        else:
                            dept_cycle.popleft()
                            continue
                        dept_cycle.rotate(-1)

                    # Allocate second seat
                    while dept_cycle and not seat2:
                        dept = dept_cycle[0]
                        if dept_queues[dept]:
                            seat2 = dept_queues[dept].popleft()
                        else:
                            dept_cycle.popleft()
                            continue
                        dept_cycle.rotate(-1)

                    if not seat1 and not seat2:
                        room_full = True
                        break

                    row_data.append({
                        "bench_no": bench_no,
                        "seat1": SimpleNamespace(**seat1.__dict__) if seat1 else None,
                        "seat2": SimpleNamespace(**seat2.__dict__) if seat2 else None,
                    })
                    bench_no += 1
                else:
                    row_data.append({"bench_no": None})
            benches_list.append(row_data)
            if room_full:
                break

        allocation.append({
            "classroom": room.room_no,
            "grid": benches_list,
        })

        if all(not q for q in dept_queues.values()):
            break

    return allocation

# ----------------- Views -----------------

def view_allotments(request):
    """Show list of all rooms"""
    rooms = Room.objects.all()
    return render(request, 'view_allotments.html', {'rooms': rooms})

def view_room_allocation(request, room_no):
    """Show allocation for a specific room"""
    room = get_object_or_404(Room, room_no=room_no)
    students = Student.objects.all()
    allocation = generate_seats(students)
    # Find the room allocation in list
    room_alloc = next((r for r in allocation if r['classroom'] == room.room_no), None)
    return render(request, 'room_allocation.html', {'room': room, 'allocation': room_alloc})

def generate_seats_view(request):
    """Show all room allocations together"""
    students = Student.objects.all()
    allocation = generate_seats(students)
    return render(request, 'generate_seats.html', {'allocations': allocation})


def view_allotments(request):
    """Show list of all rooms with links to allocations"""
    rooms = Room.objects.all()
    return render(request, 'view_allotments.html', {'rooms': rooms})


def view_room_allocation(request, room_no):
    """Show allocation for a specific room"""
    room = get_object_or_404(Room, room_no=room_no)
    students = Student.objects.all()
    allocation = generate_seats(students)
    
    # Find allocation for this room
    room_alloc = next((r for r in allocation if r['classroom'] == room.room_no), None)
    return render(request, 'room_seats.html', {'room': room, 'allocation': room_alloc})